<?php get_header();?>
  
 
<?php get_template_part('templates/banner');?>
  
  
  <section id="blogArchive">
    <div class="container">
      <div class="row">
	  
	  
		 <!-- start sidebar -->
		 <?php // fired if left sidebar chosen
			if( get_theme_mod( 'wpf_authority_sidebar_settings', 'right') == 'left' ):
			
			get_sidebar();
			
			endif;
		?>
		 <!-- end sidebar --> 
		 
	  
        <div class="col-lg-8 col-md-8 col-sm-12">
		
			 <div class="blogArchive_area">
			 			 
			 
				<?php if(have_posts()) : ?><?php while(have_posts())  : the_post(); ?>

					<?php get_template_part('post-excerpt');?>
					
				<?php endwhile; ?>

				<?php wpf_authority_page_navi(); ?>

				<?php else : ?>
					<h2 class="not_found"><?php _e('Sorry! Nothing Found', 'wpf-authority'); ?></h2>
				<?php endif; ?>					
			 

			 </div>

        </div>
		

		
		 <!-- start sidebar -->
		 <?php // fired if right sidebar chosen
			if( get_theme_mod( 'wpf_authority_sidebar_settings', 'right' ) == 'right' ):
			
			get_sidebar();
			
			endif;
		?>
		 <!-- end sidebar --> 		
		
		
      </div>
    </div>
  </section>
  <!-- End image editing  -->
      
<?php get_footer(); ?>