        <div class="col-lg-4 col-md-4 col-sm-12">
         <div class="blog_sidebar">
		 

			<?php dynamic_sidebar('page-sidebar'); ?>

		 
		  
         </div>
        </div>