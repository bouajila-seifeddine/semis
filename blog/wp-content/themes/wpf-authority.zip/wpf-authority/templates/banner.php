  <!-- start banner area -->
  
<?php  if( get_header_image() ) : ?>

  <section id="imgbanner">  
    <h2> <?php echo esc_html( get_theme_mod( 'wpf_authority_banner_title') );?> </h2>
  </section>		
	
<?php endif; ?>  
  
  <!-- End banner area -->