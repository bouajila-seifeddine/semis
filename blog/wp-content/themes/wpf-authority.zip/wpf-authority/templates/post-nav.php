	 <!-- start post pagination -->
	 <div class="post_navigation">
		<?php previous_post_link('%link'); ?> 
		<?php next_post_link( '%link' ); ?>
	 </div>
	  <!-- End post pagination -->