<div class="col-lg-12 col-md-12 col-sm-12">
	<div class="credit_links">
	 <p> <?php printf( __('Blog de <a href="%1$s">SemillasLowCost</a>', 'wpf-authority'), esc_url('https://www.semillaslowcost.com') );?> <?php printf( __('| &copy; <a href="%1$s">SemillasLowCost</a>', 'wpf-authority'), esc_url('https://www.semillaslowcost.com') );?> </p>
	</div>			
</div>