            <div class="developer">
                  <ul class="social_nav">
					
					
					<?php if( get_theme_mod('wpf_authority_footer_social_facebook') ): ?>
						<li><a href="<?php echo esc_url(get_theme_mod('wpf_authority_footer_social_facebook')); ?>" target="_blank"><i class="fa fa-facebook"></i></a></li>
					<?php endif;?>
					

					<?php if( get_theme_mod('wpf_authority_footer_social_twitter') ): ?>
						<li><a href="<?php echo esc_url(get_theme_mod('wpf_authority_footer_social_twitter')); ?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
					<?php endif;?>		
					

					<?php if( get_theme_mod('wpf_authority_footer_social_googleplus') ): ?>
						<li><a href="<?php echo esc_url(get_theme_mod('wpf_authority_footer_social_googleplus')); ?>" target="_blank"><i class="fa fa-google-plus"></i></a></li>
					<?php endif;?>	
					

					<?php if( get_theme_mod('wpf_authority_footer_social_youtube') ): ?>
						<li><a href="<?php echo esc_url(get_theme_mod('wpf_authority_footer_social_youtube')); ?>" target="_blank"><i class="fa fa-youtube"></i></a></li>
					<?php endif;?>	
					

					<?php if( get_theme_mod('wpf_authority_footer_social_linkin') ): ?>
						<li><a href="<?php echo esc_url(get_theme_mod('wpf_authority_footer_social_linkin')); ?>" target="_blank"><i class="fa fa-linkedin"></i></a></li>
					<?php endif;?>						
				  
                    
                  </ul>
            </div>